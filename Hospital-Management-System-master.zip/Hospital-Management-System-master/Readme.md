# Hospital-Management
Hello, myself Krishna Sahay. I am from Gorakhpur, Uttar Pradesh. I did my graduation from Madan Mohan Malaviya University of Technology gorakhpur. I have basic knowledge of HTML , core JAVA, c , embedded system, basic Python. My hobbies are playing cricket, badminton , algorithmic competitive coding on hackerrank , etc.,
